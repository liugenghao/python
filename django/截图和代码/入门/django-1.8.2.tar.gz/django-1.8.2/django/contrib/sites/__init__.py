default_app_config = 'django.contrib.sites.apps.SitesConfig'
